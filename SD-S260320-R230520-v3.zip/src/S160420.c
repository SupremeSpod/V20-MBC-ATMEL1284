// S160420.c
// S160420 - Conversion utility
//	     To convert a binary hexdump export (hex digits in a line) from Frhed.exe (hex editor) 
//       to a .txt file suited for Arduino IDE
//
//	     Created for the S260320 IOS
//
//	     To compile (linux OS): gcc -o S160420 S160420.c
//
//	     To run (linux OS): ./S160420 <in.txt > out.txt
//	     where: in.txt is the binary hexdump export made by Frhed.exe ("Just hex digits 
//              on a line" option), out.txt is the converted output txt for the Arduino IDE
//
//
// NOTE: If gcc give the error "fatal error: stdio.h: No such file or directory"
//       check if the build-essential lib is installed!!


#include <stdio.h>

int main()
{
  int retValue, col, counter = 0;
  unsigned int a, b;

  printf("Hex output converter - S160420\n\n");
  retValue = scanf("%1x", &a);             // Read first hex char of the line
  while (retValue > 0)
  {
    col = 1;
    while ((retValue > 0) & (col <= 16))
    {
      scanf("%1x", &b);
      if (col == 1) printf("  ");
      printf("0x%1X", a);
      printf("%1X", b);
      col++;
      counter++;
      retValue = scanf("%1x", &a);		     // Read next hex char
      if (retValue > 0) printf(", ");
    };
    printf("\n");
  }
  printf("\nTotal bytes count = %d (dec), 0x%04X (hex)\n", counter, counter);
return 0;
}
