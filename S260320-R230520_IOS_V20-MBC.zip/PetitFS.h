#ifndef PetitFS_h
#define PetitFS_h
#include "diskio.h"
#include "pff.h"
#endif  // PetitFS_h
